﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SuperSocket.Management.Server")]
[assembly: AssemblyDescription("SuperSocket.Management.Server, it is developed for server instances management")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: Guid("35548653-7b6f-4f7e-8cf1-4ce1ceea82c3")]
