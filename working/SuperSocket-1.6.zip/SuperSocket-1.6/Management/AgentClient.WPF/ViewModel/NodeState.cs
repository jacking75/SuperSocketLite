﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SuperSocket.ServerManager.Client.ViewModel
{
    public enum NodeState
    {
        Offline,
        Connecting,
        Logging,
        Connected
    }
}
